"""
API Flask para la propuesta Bluba.

- Recibe el micro-registro diario de la familia desde el HTML.
- Lo agrega como fila nueva a base_bluba.csv (la "base de datos").
- Entrena (o reutiliza) el modelo de modelo.py sobre esa misma base de datos
  y devuelve la predicción de crisis a 24h.

Ejecutar:
    python seed_dataset.py   # una sola vez, crea base_bluba.csv
    python app.py            # levanta la API en http://localhost:5000
"""
import os
from datetime import date

import pandas as pd
from flask import Flask, jsonify, request
from flask_cors import CORS

import modelo

RUTA_CSV = os.path.join(os.path.dirname(os.path.abspath(__file__)), "base_bluba.csv")

app = Flask(__name__)
CORS(app)  # Demo: se permite cualquier origen para simplificar el front-end local.

_cache = {"modelo": None, "imputador": None, "n_filas": -1}


def _asegurar_csv():
    if not os.path.exists(RUTA_CSV):
        raise FileNotFoundError(
            f"No se encontró {RUTA_CSV}. Ejecuta primero: python seed_dataset.py"
        )


def _obtener_modelo():
    """Reentrena si el número de filas cambió desde la última vez (dato nuevo guardado)."""
    df = modelo.cargar_datos(RUTA_CSV)
    if _cache["modelo"] is None or _cache["n_filas"] != len(df):
        m, imp = modelo.entrenar_modelo(df)
        _cache.update({"modelo": m, "imputador": imp, "n_filas": len(df)})
    return _cache["modelo"], _cache["imputador"], len(df)


@app.get("/api/salud")
def salud():
    return jsonify({"status": "ok"})


@app.post("/api/prediccion")
def prediccion():
    """
    Body JSON esperado:
    {
      "usuario_id": "familia_01",
      "horas_sueno": 6.5,               // o null si no se registró
      "calidad_sueno": 1,                // 1 mala, 2 regular, 3 buena | null
      "estado_basal": 1,                 // 1 irritable, 2 neutro, 3 tranquilo | null
      "nivel_apoyo": 2,                  // 1 alto, 2 medio, 3 bajo | null
      "salud_gi": 2,                     // 1 normal, 2 leve, 3 severo | null
      "cambio_rutina": 2,                // 0 ninguno, 1 leve, 2 drástico | null
      "desregulaciones_previas": 1,      // conteo 0-5 | null
      "alimentacion": 1,                 // no usado aún por el modelo
      "interaccion_social": 2,           // no usado aún por el modelo
      "notas": "texto libre"
    }
    """
    _asegurar_csv()
    body = request.get_json(force=True) or {}

    usuario_id = str(body.get("usuario_id") or "anonimo").strip()
    registro = {f: body.get(f) for f in modelo.FEATURES}

    modelo_rf, imputador, n_historico = _obtener_modelo()
    resultado = modelo.predecir(registro, modelo_rf, imputador, n_historico)

    # Persistimos el registro de hoy en la base de datos CSV. La etiqueta
    # crisis_24h queda vacía porque su desenlace real aún no se conoce.
    nueva_fila = {
        "usuario_id": usuario_id,
        "fecha": date.today().isoformat(),
        **registro,
        "alimentacion": body.get("alimentacion"),
        "interaccion_social": body.get("interaccion_social"),
        "notas": body.get("notas", ""),
        "crisis_24h": "",
    }
    df = pd.read_csv(RUTA_CSV)
    df = pd.concat([df, pd.DataFrame([nueva_fila])], ignore_index=True)
    df.to_csv(RUTA_CSV, index=False)

    return jsonify(resultado)


@app.get("/api/historial/<usuario_id>")
def historial(usuario_id):
    _asegurar_csv()
    df = pd.read_csv(RUTA_CSV)
    df_usuario = df[df["usuario_id"].astype(str) == str(usuario_id)].tail(10)
    return jsonify(df_usuario.to_dict(orient="records"))


if __name__ == "__main__":
    app.run(debug=True, port=5000)
